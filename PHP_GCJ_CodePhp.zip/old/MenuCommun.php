
				<a href="/gcj" class="btn btn-warning" role="button">Home</a>


<!-- 				<div class="btn-group">
					<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Action
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Action</a>
						<a class="dropdown-item" href="#">Another action</a>
						<a class="dropdown-item" href="#">Something else here</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="#">Separated link</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Action
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Action</a>
						<a class="dropdown-item" href="#">Another action</a>
						<a class="dropdown-item" href="#">Something else here</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="#">Separated link</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Sessions
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Consultation</a>
						<a class="dropdown-item" href="#">Inscription</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Prestations
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Consultation</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Administration
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Prestation</a>
						<a class="dropdown-item" href="#">Session</a>
						<a class="dropdown-item" href="#">Competence</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="#">Intervenant</a>
						<a class="dropdown-item" href="#">Invite</a>
						<a class="dropdown-item" href="#">Organisateur</a>
						<a class="dropdown-item" href="#">Participant</a>
						<a class="dropdown-item" href="#">Prescripteur</a>
					</div>
				</div>
 -->
				<div class="btn-group">
					<button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Connection
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item  disabled" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="/gcj/pages/Connection/Inscription" niveau="100" >S'inscrire</a>
					</div>
				</div>

