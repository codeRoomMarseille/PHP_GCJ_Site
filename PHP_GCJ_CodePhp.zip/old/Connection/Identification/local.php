		<div class="container border border-success shadow-lg p-3 mb-5 bg-white rounded">
			<form>
				<div class="form-group">
					<label for="exampleInputEmail1">Adresse mail</label>
					<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Adresse mail ?">
					<small id="emailHelp" class="form-text text-muted">Nous ne partagerons jamais votre email.</small>
				</div>
				<div class="form-group">
					<label for="exampleInputPassword1">Mot de passe</label>
					<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Mot de passe ?">
				</div>
				<div class="form-group form-check">
					<input type="checkbox" class="form-check-input" id="exampleCheck1">
					<label class="form-check-label" for="exampleCheck1">Vérifiez moi</label>
				</div>
				<button type="submit" class="btn btn-primary">Valider</button>
			</form>
		</div>
