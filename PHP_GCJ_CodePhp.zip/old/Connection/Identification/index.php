<?php require_once('c:/wamp64/www/gcj/commun/moteur.php'); ?> 
