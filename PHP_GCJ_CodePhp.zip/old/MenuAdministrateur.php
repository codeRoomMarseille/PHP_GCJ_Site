

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Compétence Pédagogique
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Compétence Technique
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Droits
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Disponibilité
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Indisponibilité
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Inscription
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Intervenant
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Liste Attente
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Prestation
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Salle
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Session
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Utilisateurs
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#" niveau="100" >Acquérir</a>
						<a class="dropdown-item" href="#" niveau="100" >Ajouter</a>
						<a class="dropdown-item" href="#" niveau="100" >Annuler</a>
						<a class="dropdown-item" href="#" niveau="100" >Consulter</a>
						<a class="dropdown-item" href="#" niveau="100" >Créer</a>
						<a class="dropdown-item" href="#" niveau="100" >Déclarer</a>
						<a class="dropdown-item" href="#" niveau="100" >Dispenser</a>
						<a class="dropdown-item" href="#" niveau="100" >Enlever</a>
						<a class="dropdown-item" href="#" niveau="100" >Modifier</a>
						<a class="dropdown-item" href="#" niveau="100" >S’inscrire</a>
						<a class="dropdown-item" href="#" niveau="100" >Se connecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Se déconnecter</a>
						<a class="dropdown-item" href="#" niveau="100" >Supprimer</a>
					</div>
				</div>

