<?php require_once('c:/wamp64/www/gcj/commun/haut.php'); ?> 


<?php require_once('./local.php'); ?>


<?php require_once('c:/wamp64/www/gcj/commun/bas.php'); ?> 


