<?php

// $manager = new DisponibiliteManager($db);

$classe='Attente';
$titres=['Prestation','Contenu','Organisation','Prerequis','Maximum','Login','EtatConnection','Nom','Prenom','Mail','Telephone','Adresse'];
$messageAttention = 'Attention';
$messageListeVide = 'la liste est vide';
$messageAlerteListe = 'Page réservée aux administrateurs du site.';


require_once($repertoireCommun.'masquePageListe.php'); 


