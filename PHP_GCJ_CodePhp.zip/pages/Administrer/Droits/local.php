<?php

// $manager = new DisponibiliteManager($db);

$classe='Droit';
$titres=['Nom','Niveau'];
$messageAttention = 'Attention';
$messageListeVide = 'la liste est vide';
$messageAlerteListe = 'Page réservée aux administrateurs du site.';


require_once($repertoireCommun.'masquePageListe.php'); 

