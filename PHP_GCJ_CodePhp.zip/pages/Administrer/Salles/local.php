<?php

// $manager = new DisponibiliteManager($db);

$classe='Salle';
$titres=['Nom','Adresse'];
$messageAttention = 'Attention';
$messageListeVide = 'la liste est vide';
$messageAlerteListe = 'Page réservée aux administrateurs du site.';


require_once($repertoireCommun.'masquePageListe.php'); 




