<?php 
	$repertoireCommun=$_SERVER['DOCUMENT_ROOT'].'/gcj/commun/';
	require_once($repertoireCommun.'moteur.php'); 
?> 