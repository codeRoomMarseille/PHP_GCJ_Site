<?php 

// Vérification de la validité des informations


// Hachage du mot de passe

$pass_hache = password_hash($_POST['pass'], PASSWORD_DEFAULT);


// Insertion

$req = $bdd->prepare('INSERT INTO membres(pseudo, pass, email, date_inscription) VALUES(:pseudo, :pass, :email, CURDATE())');

$req->execute(array(

    'pseudo' => $pseudo,

    'pass' => $pass_hache,

    'email' => $email));





    une page d'inscription ;

    une page de connexion ;

    une page de déconnexion.
    
    password_hash
