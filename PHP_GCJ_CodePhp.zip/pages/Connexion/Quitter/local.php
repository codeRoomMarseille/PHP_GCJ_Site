<div class="container border border-success rounded">

  <h2><span class="badge badge-pill badge-success small" > Quitter </span> </h2>

  <form>

    <!-- <legend><small>Merci de votre visite. A bientôt !</small></legend> -->
     
    <div class="form-row">
 
    	<div class="form-group col-md-6">
			Déjà ? Merci de votre visite. A bientôt parmi nous, j'espère. Nous serons très heureux de vous revoir.
      	</div>

     	<div class="form-group col-md-6">

        	<button type="submit" class="badge badge-pill badge-danger small" >Confirmer la déconnexion</button>
          
	    </div>
    </div>

  </form>
</div>

<!-- //https://developer.mozilla.org/fr/docs/Web/Guide/HTML/Formulaires/Validation_donnees_formulaire -->
<!-- https://laravel.sillo.org/bootstrap-4-les-formulaires-1-2/ -->