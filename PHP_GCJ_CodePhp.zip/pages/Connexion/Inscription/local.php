<div class="container border border-success rounded">

  <h2><span class="badge badge-pill badge-success small" > Inscription </span> </h2>

  <form>

    <legend><small>Merci de renseigner vos informations. Vos données ne seront jamais communiquées.</small></legend>

    <div class="form-row">
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm" for="nom">Nom</label>
        <input type="text" class="form-control form-control-sm " id="nom" placeholder="Nom" required >
      </div>
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm" for="prenom">Prénom</label>
        <input type="text" class="form-control form-control-sm " id="prenom" placeholder="Prénom" required >
      </div>
    </div>


    <div class="form-row">
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm" for="nom">Login</label>
        <input type="text" class="form-control form-control-sm " id="login" placeholder="Login" required >
        <small id="passwordHelpBlock" class="form-text text-muted">
          Pseudonyme pour vos futures connections.
        </small>
      </div>
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm" for="inputEmail4">Mail</label>
        <input type="email" class="form-control form-control-sm " id="mail" placeholder="Mail" required >
      </div>
    </div>


    <div class="form-row">
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm" for="nom">Téléphone</label>
        <input type="text" class="form-control form-control-sm " id="telephone" placeholder="0n nn nn nn nn" required pattern="[0-9]{2}[ ][0-9]{2}[ -][0-9]{2}[ -][0-9]{2}[ -][0-9]{2}[ -]">
        <small id="passwordHelpBlock" class="form-text text-muted">
          
        </small>
      </div>
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm" for="inputEmail4">Mobile</label>
        <input type="text" class="form-control form-control-sm " id="mobile" placeholder="06 nn nn nn nn" required pattern="[0-9]{2}[ ][0-9]{2}[ -][0-9]{2}[ -][0-9]{2}[ -][0-9]{2}[ -]">
        <small id="passwordHelpBlock" class="form-text text-muted">
          Pour SMS en cas d'urgence
        </small>
      </div>
    </div>


    <div class="form-row">
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm"  for="inputPassword4">Password</label>
        <input type="password" class="form-control form-control-sm " id="inputPassword1" placeholder="Ecrire une première fois votre mot de passe" required >
        <small id="passwordHelpBlock" class="form-text text-muted">
          Le mot de passe doit contenir de 8 à 20 caractères, des lettres et des nombres.
        </small>
      </div>
      <div class="form-group col-md-6">
        <label  class="col-sm-2 col-form-label col-form-label-sm" for="inputPassword4">Password</label>
        <input type="password" class="form-control form-control-sm " id="inputPassword2" placeholder="Ecrire une deuxième fois votre mot de passe par sécurité" required >
        <small id="passwordHelpBlock" class="form-text text-muted">
          
        </small>
      </div>
    </div>

    <div class="form-group">
      <label class="col-sm-2 col-form-label col-form-label-sm"  for="inputAddress">Addresse</label>
      <input type="text" class="form-control form-control-sm " id="inputAddress" placeholder="Adresse" required >
    </div>

    <div class="form-row">
      <div class="form-group col-md-6">

      </div>
      <div class="form-group col-md-6">

        <button type="submit" class="badge badge-pill badge-danger small" >Enregistrer votre inscription</button>
          
      </div>
    </div>

  </form>
</div>

<!-- //https://developer.mozilla.org/fr/docs/Web/Guide/HTML/Formulaires/Validation_donnees_formulaire -->
<!-- https://laravel.sillo.org/bootstrap-4-les-formulaires-1-2/ -->