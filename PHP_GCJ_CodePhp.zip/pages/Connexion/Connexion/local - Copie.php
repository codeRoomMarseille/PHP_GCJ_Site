

<div class="container">

<div class="row">
<div class="col-md-offset-2 col-md-8">
<h1> Inscription <br/> <small> Merci de renseigner vos informations </small></h1>
</div>
</div>

<div class="row">
<div class="col-md-offset-2 col-md-3">
<div class="form-group">
<label for="Nom">Nom</label>
<input type="text" class="form-control" id="nom" placeholder="Nom">
</div>
</div>
<div class="col-md-offset-1 col-md-3">
<div class="form-group">
<label for="Prenom">Prénom</label>
<input type="text" class="form-control" id="prenom" placeholder="Prénom">
</div>
</div>
</div>

<div class="row">
<div class="col-md-offset-2 col-md-7">
<div class="form-group">
<label for="Email">Email address</label>
<input type="text" class="form-control" id="email" placeholder="Enter email">
</div>
</div>
</div>

<div class="row">
<div class="col-md-offset-2 col-md-3">
<div class="form-group">
<label for="Password">Mot de passe</label>
<input type="password" class="form-control" id="password" placeholder="Mot de passe">
</div>
</div>
<div class="col-md-offset-1 col-md-3">
<div class="form-group">
<label for="Vpassword">Vérification mot de passe</label>
<input type="password" class="form-control" id="vpassword" placeholder="Vérification mot de passe">
</div>
</div>
</div>

<div class="row">
<div class="col-md-offset-2 col-md-3">
<div class="input-group">
<span class="input-group-addon glyphicon glyphicon-earphone"></span>
<input type="text" class="form-control" placeholder="Téléphone" aria-describedby="basic-addon1">
</div>
<div class="input-group">
<span class="input-group-addon glyphicon glyphicon-globe"></span>
<input type="text" class="form-control" placeholder="Adresse" aria-describedby="basic-addon1">
</div>
</div>
</div>

<br/>
<div class="row">
<div class="col-md-offset-5 col-md-1">
<button type="button" class="btn btn-primary">Envoyer mes informations</button>
</div>
</div>

</div>




		<script>
			


jQuery(document).ready(function(){

	jQuery("#register").submit(function(){
	
		if (jQuery("#nom").val() == "") {
			alert("Merci de saisir votre nom");
			jQuery("#nom").focus();
			return false;
		}
		if (jQuery("#prenom").val() == "") {
			alert("Merci de saisir votre prenom");
			jQuery("#prenom").focus();
			return false;
		}
		if (jQuery("#email").val() == "" || valideEmail(jQuery("#email").val()) ) {
			alert("Merci de saisir votre adresse email correcte");
			jQuery("#email").focus();
			return false;
		}
		if (jQuery("#password").val() == "") {
			alert("Merci de saisir votre mot de passe");
			jQuery("#password").focus();
			return false;
		}
		if (jQuery("#vpassword").val() == "") {
			alert("Merci de saisir la vérification de votre mot de passe");
			jQuery("#vpassword").focus();
			return false;
		}
	



			
		</script>

	<body class="my_background">

		<div class="container">
			<form role="form" id="register" method="post" action="SUCCESS">
				<div class="row">
					<div class="col-md-offset-2 col-md-8">
						<h1> Inscription <br/> <small> Merci de renseigner vos informations </small></h1>
					</div>
				</div>

				<div class="row">
					<div class="col-md-offset-2 col-md-3">
					<div class="form-group">
						<label for="Nom">Nom</label>
						<input type="text" class="form-control" id="nom" placeholder="Nom" required>
					</div>
					</div>
					<div class="col-md-offset-1 col-md-3">
						<div class="form-group">
							<label for="Prenom">Prénom</label>
							<input type="text" class="form-control" id="prenom" placeholder="Prénom" required>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-offset-2 col-md-7">
						<div class="form-group">
							<label for="Email">Email address</label>
							<input type="text" class="form-control" id="email" placeholder="Enter email" required>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-offset-2 col-md-3">
						<div class="form-group">
							<label for="Password">Mot de passe</label>
							<input type="password" class="form-control" id="password" placeholder="Mot de passe" required>
						</div>
					</div>
					<div class="col-md-offset-1 col-md-3">
						<div class="form-group">
							<label for="Vpassword">Vérification mot de passe</label>
							<input type="password" class="form-control" id="vpassword" placeholder="Vérification mot de passe" required>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-offset-2  col-md-3">
						<div class="input-group">
							<span class="input-group-addon glyphicon glyphicon-phone"> </span>
							<input type="text" class="form-control" id="tel" placeholder="Numéro de téléphone"  pattern="[0-9]{2}[ ][0-9]{2}[ -][0-9]{2}[ -][0-9]{2}[ -][0-9]{2}[ -]" >
						</div>
					</div>
					<div class="col-md-offset-1  col-md-3">
						<div class="input-group">
							<span class="input-group-addon glyphicon glyphicon-globe"> </span>
							<input type="text" class="form-control" id="adresse" placeholder="Adresse" required>
						</div>
					</div>
					<br/>
					<div class="row">
						<div class="col-md-offset-5  col-md-1">
							<button type="submit" class="btn btn-primary">S'incrire</button>
						</div>
					</div>
				</div>

			</div>
		</form>
	</body>
</html>