


<div class="container border border-success rounded">

  <h2><span class="badge badge-pill badge-success small" > Connexion </span> </h2>

  <form  action="index.php" method="post">

    <div class="form-row">
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm" for="nom">Login</label>
        <input type="text" class="form-control form-control-sm " id="login" name="login" placeholder="Login" required >
        <small id="passwordHelpBlock" class="form-text text-muted">
          
        </small>
      </div>
      <div class="form-group col-md-6">
        <label class="col-sm-2 col-form-label col-form-label-sm"  for="inputPassword4">Password</label>
        <input type="password" class="form-control form-control-sm " id="inputPassword1" name="inputPassword1" placeholder="Mot de passe" required >
        <small id="passwordHelpBlock" class="form-text text-muted">
          
        </small>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group col-md-6">

      </div>
      <div class="form-group col-md-6">

        <button type="submit" class="badge badge-pill badge-danger small" >Se connecter</button>
          
      </div>
    </div>

  </form>
</div>

<!-- //https://developer.mozilla.org/fr/docs/Web/Guide/HTML/Formulaires/Validation_donnees_formulaire -->
<!-- https://laravel.sillo.org/bootstrap-4-les-formulaires-1-2/ -->
<!-- https://openclassrooms.com/fr/courses/1401411-creer-son-forum-de-toutes-pieces/1401751-inscription-et-connexion -->