
	

<div class="container" style="margin-top:30px">
  <div class="row">
    
    <div class="col-sm-4">
      
      <h2 ><span class="badge badge-pill badge-success">Qui sommes nous ?</span></h2>
      <h5>Notre photo</h5>
      <div class="fakeimg">Trop timides pour afficher notre photo ! On s'excuse.</div>
      <!-- <br> -->
      <p>Nous sommes un groupe d'informaticiens chez Orange en grande partie autodidactes, passionnés par le code informatique. </p>
      
      <h3><span class="badge badge-pill badge-success">Quelques liens</span></h3>
      <p>Leur esprit, leur philosophie, l'aide qu'ils nous ont apporté d'une façon ou d'une autre expliquent leur présence ici.</p>
      <ul class="nav nav-pills flex-column">
        
        <li class="nav-item ">
          <a class="nav-link btn btn-outline-success" href="https://openclassrooms.com/fr/" target="BLANK">Openclassrooms</a>
        </li>
       
        <li class="nav-item">
          <a class="nav-link btn btn-outline-success" href="https://www.fun-mooc.fr/" target="BLANK">FUN</a>
        </li>

        <li class="nav-item">
          <a class="nav-link btn btn-outline-success" href="https://solerni.com/" target="BLANK">Solerni</a>
        </li>


        <li class="nav-item">
          <a class="nav-link btn btn-outline-success" href="https://www.orange.fr/portail" target="BLANK">Orange</a>
        </li>
       
        <li class="nav-item">
          <a class="nav-link btn btn-outline-success" href="https://simplon.co/" target="BLANK">Simplon.co</a>
        </li>
    
        <li class="nav-item">
          <a class="nav-link btn btn-outline-success" href="https://www.fondationorange.com/" target="BLANK">Fondation Orange</a>
        </li>

        <li class="nav-item">
          <a class="nav-link btn btn-outline-success" href="https://mooc-francophone.com/liste-mooc-en-francais/?tax_course_discipline=mooc&tax_course_length=informatique-programmation&tax_course_level=&tax_course_location=&wpas=1" target="BLANK">MOOC Francophone</a>
        </li>
     
        <li class="nav-item">
          <a class="nav-link btn btn-outline-success" href="https://www.my-mooc.com/fr/categorie/informatique-programmation" target="BLANK">MY Mooc</a>
        </li>
     
      </ul>

      <hr class="d-sm-none">
   
    </div>
    
    <div class="col-sm-8">
       
      <h2 ><span class="badge badge-pill badge-success">Notre démarche</span></h2>
      <h5>Mûrement réfléchie............ mais pas trop longtemps, tout de même !</h5>
      <!-- <div class="fakeimg">Fake Image</div> -->
      <p>Passionnés par le code informatique, nous avons pour coutume d'initier nos collègues. Pour cela, au sein d'Orange, nous avons fondé la "Guilde des Codeurs Juniors". Nous avons décidé de proposer nos initiations à nos familles, nos amis, nos copains, nos voisins... et finalement aux autres ; bref, à toutes celles et ceux qui en ont besoin, ...... dans la limite des places disponibles.</p>
      <p>Ces initiations s'adressent aux débutant(e)s en codage informatique motivés pour apprendre (collégien(e)s, lycéen(e)s adultes), qui savent se servir d'un ordinateur. Elles seront dispensées sur le site Orange de St Mauront 93 rue Félix Pyat à Marseille, juste à côté du métro National.</p>
      <p>En fait, nous sommes tous des professionnels de l'auto apprentissage. Nous enseignons les bases, le fonctionnement, le modèle, les principes d'un sujet en 6 H. Nous complétons en faisant vivre nos méthodes d'autoapprentissage. Ensuite nous accompagnons nos invités pour construire ensemble leur chemin d'apprentissage via des Moocs gratuits disponibles sur Internet. Nos invités sont parés pour continuer en autonomie.</p>
      <p>Alors que le France souhaite mettre en adéquation les compétences et les besoins des entreprises nous souhaiterions apporter notre modeste contribution.</p>
      <p>Cette proposition est issue de l’initiative de quelques collègues informaticiens chez Orange. Nous apprécions que notre entreprise nous donne les moyens de partager notre passion pour le code informatique avec notre entourage. </p>
     
      <h2 ><span class="badge badge-pill badge-success">La légende de la Guilde des Codeurs Juniors</span></h2>
      <h5>Telle qu'elle est contée dans les contrées. </h5>
      <!-- <div class="fakeimg">Fake Image</div> -->
      <p>C’est en l'an deux mille dix huit, par un petit matin de printemps joyeux, au sein de la Code Room Marseille, que naquit la Guilde des Codeurs Juniors.</p>
      <p>Incultes en sciences occultes, incapables de transformer le plomb en or, les quatre membres fondateurs Oncle Fienga, Oncle Olivier, Oncle Renard et Oncle Picou avaient néanmoins déchiffré, après lecture de quelques Codex et autres grimoires poussiéreux , moult notions de codage informatique.
      <p>Forts de cette science embryonnaire, il décidèrent de fonder la Guilde des Codeurs Juniors et de partager leur maigre savoir en espérant que d’autres se feraient plaisir en apprenant de nouveaux langages et en codant de superbes réalisations.</p>
      <p>C'est alors que tout aussi désireux d'aider, Dame Audibert et Maitre Sinclair s'en vinrent leur prêter main forte.</p>
      <p>Toi l'Apprenti Codeur, jouvenceau ou jouvencelle, vient donc rejoindre la Guilde des Codeurs Juniors et partager ce savoir qui un jour fera de toi un codeur accompli.</p>
      <p>Pour la Guilde des Codeurs Juniors, n’hésitez pas à publier et claironner ce récit par monts et par vaux.</p>
       <br>

    </div>

  </div>
</div>