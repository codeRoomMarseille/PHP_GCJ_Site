
<?php
  header('Location: /gcj/pages');
  exit();
?>