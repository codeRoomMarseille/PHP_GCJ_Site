<?php
class Prestation
{
  
  private $_id, $_nom, $_objectif, $_contenu, $_organisation, $_prerequis, $_maximum ;
    
  public function __construct(array $donnees)
  {
    $this->hydrate($donnees);
  }
   
  public function hydrate(array $donnees)
  {
    foreach ($donnees as $key => $value)
    {
      $method = 'set'.ucfirst($key);
     if (method_exists($this, $method))
      {
        // echo '<p>'. $key . '-------' .$value.  '-------' .$method. '------- existe'.'</p>';
        $this->$method($value);
      }
    }
  }
  
   // GETTERS //
  public function getId()
  {
     return $this->_id;
  }

  public function getNom()
  {
     return $this->_nom;
  }

  public function getObjectif()
  {
     return $this->_objectif;
  }

  public function getContenu()
  {
     return $this->_contenu;
  }

  public function getOrganisation()
  {
     return $this->_organisation;
  }

  public function getPrerequis()
  {
     return $this->_prerequis;
  }

  public function getMaximum()
  {
     return $this->_maximum;
  }

  // SETTERS //
   
  public function setId($id)
  {
      $id = (int) $id;
      if ($id > 0){
          $this->_id=$id;
      }
  }

  public function setNom($nom)
  {
     if (is_string($nom)){
      $this->_nom=$nom;
     }
  }

  public function setObjectif($objectif)
  {
     if (is_string($objectif)){
      $this->_objectif=$objectif;
     }
  }

  public function setContenu($contenu)
  {
     if (is_string($contenu)){
      $this->_contenu=$contenu;
     }
  }

  public function setOrganisation($organisation)
  {
     if (is_string($organisation)){
      $this->_organisation=$organisation;
     }
  }

  public function setPrerequis($prerequis)
  {
     if (is_string($prerequis)){
      $this->_prerequis=$prerequis;
     }
  }

  public function setMaximum($maximum)
  {
    $maximum = (int) $maximum;
    if ($maximum > 0){
      $this->_maximum=$maximum;
    }
  }
 
}