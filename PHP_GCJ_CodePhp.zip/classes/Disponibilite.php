<?php
class Disponibilite
{
  
   private $_id,$_genre,$_date,$_login,$_etatconnection,$_nom,$_prenom,$_mail,$_telephone,$_adresse;

    
  public function __construct(array $donnees)
  {
    $this->hydrate($donnees);
  }
  
   
  public function hydrate(array $donnees)
  {
    foreach ($donnees as $key => $value)
    {
      $method = 'set'.ucfirst($key);
     if (method_exists($this, $method))
      {
        $this->$method($value);
      }
    }
  }

  
   // GETTERS //
 
  public function getId()
  {
     return $this->_id;
  }

  public function getGenre()
  {
     return $this->_genre;
  }

  public function getDate()
  {
     return $this->_date;
  }

  public function getLogin()
  {
     return $this->_login;
  }

  public function getEtatconnection()
  {
     return $this->_etatconnection;
  }

  public function getNom()
  {
     return $this->_nom;
  }

  public function getPrenom()
  {
     return $this->_prenom;
  }

  public function getMail()
  {
     return $this->_mail;
  }

  public function getTelephone()
  {
     return $this->_telephone;
  }

  public function getAdresse()
  {
     return $this->_adresse;
  }



  // SETTERS //
   
  public function setId($id)
  {
      $id = (int) $id;
     if ($id > 0){
          $this->_id=$id;
      }
  }
   
  public function setGenre($genre)
  {
     if (is_string($genre)){
          $this->_genre=$genre;
      }
  }

  public function setDate($date)
  {
     if (is_string($date)){
          $this->_date=$date;
      }
  }

  public function setLogin($login)
  {
     if (is_string($login)){
          $this->_login=$login;
      }
  }

  public function setEtatconnection($etatconnection)
  {
     if (is_string($etatconnection)){
          $this->_etatconnection=$etatconnection;
      }
  }

  public function setNom($nom)
  {
     if (is_string($nom)){
          $this->_nom=$nom;
      }
  }

  public function setPrenom($prenom)
  {
     if (is_string($prenom)){
          $this->_prenom=$prenom;
      }
  }

  public function setMail($mail)
  {
     if (is_string($mail)){
          $this->_mail=$mail;
      }
  }

  public function setTelephone($telephone)
  {
     if (is_string($telephone)){
          $this->_telephone=$telephone;
      }
  }

  public function setAdresse($adresse)
  {
     if (is_string($adresse)){
          $this->_adresse=$adresse;
      }
  }


 
}