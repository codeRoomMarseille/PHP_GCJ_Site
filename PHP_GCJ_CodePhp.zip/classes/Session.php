<?php
class Session
{
  
  private $_id, $_nom,  $_date,  $_nomSalle, $_adresse,  $_inscrits, $_maximum ;
    
  public function __construct(array $donnees)
  {
    $this->hydrate($donnees);
  }
  
   
  public function hydrate(array $donnees)
  {
    foreach ($donnees as $key => $value)
    {
      $method = 'set'.ucfirst($key);
     if (method_exists($this, $method))
      {
        // echo '<p>'. $key . '-------' .$value.  '-------' .$method. '------- existe'.'</p>';
        $this->$method($value);
      }
    }
  }
  
   // GETTERS //
  
public function getId()
{
   return $this->_id;
}

public function getNom()
{
   return $this->_nom;
}


public function getNomSalle()
{
   return $this->_nomSalle;
}

public function getDate()
{
   return $this->_date;
}

public function getAdresse()
{
   return $this->_adresse;
}

public function getInscrits()
{
   return $this->_inscrits;
}

public function getMaximum()
{
   return $this->_maximum;
}



  // SETTERS //
   
  public function setId($id)
  {
      $id = (int) $id;
      if ($id > 0){
          $this->_id=$id;
      }
  }



  public function setNom($nom)
  {
     if (is_string($nom)){
      $this->_nom=$nom;
     }
  }


public function setNomSalle($nomSalle)
{
   if (is_string($nomSalle)){
           $this->_nomSalle=$nomSalle;
    }
}


public function setDate($date)
{
        $this->_date=$date;
}

public function setAdresse($adresse)
{
   if (is_string($adresse)){
           $this->_adresse=$adresse;
    }
}

public function setInscrits($inscrits)
{
   if (is_string($inscrits)){
           $this->_inscrits=$inscrits;
    }
}

public function setMaximum($maximum)
{
  $maximum = (int) $maximum;
  if ($maximum > 0){
    $this->_maximum=$maximum;
  }
}



 
}