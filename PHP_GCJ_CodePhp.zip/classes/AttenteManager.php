<?php
class AttenteManager extends Manager
{
  public $_requete='SELECT prestation.Nom as Prestation,prestation.Objectif,prestation.Contenu, prestation.Organisation, prestation.Prerequis , prestation.Maximum , acteur.Login,acteur.EtatConnection, acteur.Nom, acteur.Prenom, acteur.Mail, acteur.Telephone, acteur.Adresse from attente,acteur, prestation where attente.id_Acteur = acteur.id or attente.id_Prestation = prestation.id  '; 
  public $_natureClasse='Attente'; 
 
  public function __construct($db)
  {
    parent::setRequete($this->_requete);
    parent::setNatureclasse($this->_natureClasse);
    parent::__construct($db);
  }

}


