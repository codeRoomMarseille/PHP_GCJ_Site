<?php
class ActeurManager extends Manager
{
  public $_requete='SELECT id, id_NiveauDroit as NiveauDroit, Login, Password, EtatConnection, Nom, Prenom, Mail, Telephone, Adresse FROM `Acteur` '; 
  public $_natureClasse='Acteur'; 
 
  public function __construct($db)
  {
    parent::setRequete($this->_requete);
    parent::setNatureclasse($this->_natureClasse);
    parent::__construct($db);
  }

}

