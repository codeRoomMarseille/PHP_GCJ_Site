<?php
class Manager
{
  private $_db; // Instance de PDO
  private $_requete; 
  protected $_natureClasse; 
   

  protected function __construct($db)
  {
    $this->setDb($db);
  }
 
  
  private function setDb(PDO $db)
  {
    $this->_db = $db;
  }

  protected function setRequete($requete)
  {
     if (is_string($requete)){
          $this->_requete=$requete;
      }
  }


  protected function setNatureclasse($natureclasse)
  {
     if (is_string($natureclasse)){
          $this->_natureclasse=$natureclasse;
      }
  }
  

  public function getAll()
  {
    $retour = [];
    
    $natureClasse = $this->_natureClasse; 
    $q = $this->_db->prepare($this->_requete);
    
    $q->execute([]);
    
    while ($donnees = $q->fetch(PDO::FETCH_ASSOC))
    {
      $retour[] = new $natureClasse($donnees);
    }
    
    return $retour;

  }


}