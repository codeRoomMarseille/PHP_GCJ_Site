<?php
class SessionManager extends Manager
{
  public $_requete='SELECT se.id, pr.nom, se.date,sa.nom as nomSalle,sa.adresse,se.Inscrits,pr.Maximum as maximum FROM `session` se,`prestation` pr,`salle` sa WHERE se.id_Prestation = pr.id and se.id_Salle = sa.id '; 
  public $_natureClasse='Session'; 
 
  public function __construct($db)
  {
    parent::setRequete($this->_requete);
    parent::setNatureclasse($this->_natureClasse);
    parent::__construct($db);
  }

}