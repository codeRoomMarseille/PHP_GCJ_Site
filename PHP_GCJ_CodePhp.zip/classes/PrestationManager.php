<?php
class PrestationManager extends Manager
{
  public $_requete='SELECT * FROM Prestation'; 
  public $_natureClasse='Prestation'; 
 
  public function __construct($db)
  {
    parent::setRequete($this->_requete);
    parent::setNatureclasse($this->_natureClasse);
    parent::__construct($db);
  }

}

