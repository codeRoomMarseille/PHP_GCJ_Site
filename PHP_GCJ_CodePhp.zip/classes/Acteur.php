<?php
class Acteur
{
  
  private $_id, $_niveaudroit, $_login,  $_password, $_etatconnection, $_nom,  $_prenom, $_mail, $_telephone,  $_adresse ;
    
  public function __construct(array $donnees)
  {
    $this->hydrate($donnees);
  }
  
   
  public function hydrate(array $donnees)
  {
    foreach ($donnees as $key => $value)
    {
      $method = 'set'.ucfirst($key);
     if (method_exists($this, $method))
      {
        // echo '<p>'. $key . '-------' .$value.  '-------' .$method. '------- existe'.'</p>';
        $this->$method($value);
      }
    }
  }
  
   // GETTERS //
  
  public function getId()
  {
     return $this->_id;
  }


  public function getType()
  {
     return $this->_type;
  }

  public function getNiveaudroit()
  {
     return $this->_niveaudroit;
  }

  public function getLogin()
  {
     return $this->_login;
  }

  public function getPassword()
  {
     return $this->_password;
  }

  public function getEtatconnection()
  {
     return $this->_etatconnection;
  }

  public function getNom()
  {
     return $this->_nom;
  }

  public function getPrenom()
  {
     return $this->_prenom;
  }

  public function getMail()
  {
     return $this->_mail;
  }

  public function gettelephone()
  {
     return $this->_telephone;
  }

  public function getAdresse()
  {
     return $this->_adresse;
  }








  // SETTERS //
   
  public function setId($id)
  {
      $id = (int) $id;
      if ($id > 0){
          $this->_id=$id;
      }
  }

public function setNiveaudroit($niveaudroit)
  {
      $niveaudroit = (int) $niveaudroit;
     if ($niveaudroit > 0){
          $this->_niveaudroit=$niveaudroit;
      }
  }


  public function setLogin($login)
  {
     if (is_string($login)){
          $this->_login=$login;
      }
  }

  public function setPassword($password)
  {
     if (is_string($password)){
          $this->_password=$password;
      }
  }

  public function setEtatconnection($etatconnection)
  {
     if (is_string($etatconnection)){
          $this->_etatconnection=$etatconnection;
      }
  }

  public function setNom($nom)
  {
     if (is_string($nom)){
          $this->_nom=$nom;
      }
  }

  public function setPrenom($prenom)
  {
     if (is_string($prenom)){
          $this->_prenom=$prenom;
      }
  }

  public function setMail($mail)
  {
     if (is_string($mail)){
          $this->_mail=$mail;
      }
  }

  public function settelephone($telephone)
  {
     if (is_string($telephone)){
          $this->_telephone=$telephone;
      }
  }

  public function setAdresse($adresse)
  {
     if (is_string($adresse)){
          $this->_adresse=$adresse;
      }
  }




 
}