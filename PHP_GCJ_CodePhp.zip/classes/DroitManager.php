<?php
class DroitManager extends Manager
{
  public $_requete='SELECT * FROM `droit` '; 
  public $_natureClasse='Droit'; 
 
  public function __construct($db)
  {
    parent::setRequete($this->_requete);
    parent::setNatureclasse($this->_natureClasse);
    parent::__construct($db);
  }

}



