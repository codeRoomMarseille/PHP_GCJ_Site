<?php
class SalleManager extends Manager
{
  public $_requete='SELECT * FROM `salle` '; 
  public $_natureClasse='Salle'; 
 
  public function __construct($db)
  {
    parent::setRequete($this->_requete);
    parent::setNatureclasse($this->_natureClasse);
    parent::__construct($db);
  }

}


