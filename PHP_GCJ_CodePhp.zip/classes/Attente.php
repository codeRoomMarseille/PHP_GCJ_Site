<?php
class Attente
{
  
  private $_id, $_contenu,  $_organisation, $_prerequis,  $_maximum,  $_login,  $_etatconnection, $_nom,  $_prenom, $_mail, $_telephone,  $_adresse ;
    
  public function __construct(array $donnees)
  {
    $this->hydrate($donnees);
  }
  
   
  public function hydrate(array $donnees)
  {
    foreach ($donnees as $key => $value)
    {
      $method = 'set'.ucfirst($key);
     if (method_exists($this, $method))
      {
        // echo '<p>'. $key . '-------' .$value.  '-------' .$method. '------- existe'.'</p>';
        $this->$method($value);
      }
    }
  }
  
   // GETTERS //
  
  public function getId()
  {
     return $this->_id;
  }

  public function getContenu()
  {
     return $this->_contenu;
  }

   public function getOrganisation()
  {
     return $this->_organisation;
  }
   
  public function getPrerequis()
  {
     return $this->_prerequis;
  }

  public function getMaximum()
  {
     return $this->_maximum;
  }


  public function getLogin()
  {
     return $this->_login;
  }

  public function getEtatconnection()
  {
     return $this->_etatconnection;
  }

  public function getNom()
  {
     return $this->_nom;
  }

  public function getPrenom()
  {
     return $this->_prenom;
  }

  public function getMail()
  {
     return $this->_mail;
  }

  public function getTelephone()
  {
     return $this->_telephone;
  }

  public function getAdresse()
  {
     return $this->_adresse;
  }

  public function getPrestation()
  {
     return $this->_prestation;
  }

  // SETTERS //
   
   public function setId($id)
   {
        $id = (int) $id;
        if ($id > 0){
            $this->_id=$id;
        }
    }

  public function setContenu($contenu)
  {
     if (is_string($contenu)){
          $this->_contenu=$contenu;
      }
  }

  public function setOrganisation($organisation)
  {
     if (is_string($organisation)){
          $this->_organisation=$organisation;
      }
  }

  public function setPrerequis($prerequis)
  {
     if (is_string($prerequis)){
          $this->_prerequis=$prerequis;
      }
  }

  public function setMaximum($maximum)
  {
     if (is_string($maximum)){
          $this->_maximum=$maximum;
      }
  }

  public function setLogin($login)
  {
     if (is_string($login)){
          $this->_login=$login;
      }
  }

  public function setEtatconnection($etatconnection)
  {
     if (is_string($etatconnection)){
          $this->_etatconnection=$etatconnection;
      }
  }

  public function setNom($nom)
  {
     if (is_string($nom)){
          $this->_nom=$nom;
      }
  }

  public function setPrenom($prenom)
  {
     if (is_string($prenom)){
          $this->_prenom=$prenom;
      }
  }

  public function setMail($mail)
  {
     if (is_string($mail)){
          $this->_mail=$mail;
      }
  }

  public function setTelephone($telephone)
  {
     if (is_string($telephone)){
          $this->_telephone=$telephone;
      }
  }

  public function setAdresse($adresse)
  {
     if (is_string($adresse)){
          $this->_adresse=$adresse;
      }
  }

  public function setPrestation($prestation)
  {
     if (is_string($prestation)){
          $this->_prestation=$prestation;
      }
  }

 
}