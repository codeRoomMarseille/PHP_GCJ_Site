<?php
class CompetenceManager extends Manager
{
  public $_requete='SELECT Competence.id , Competence.TypeCompetence as Type, Competence.id_Prestation as Prestation FROM `Competence` '; 
  public $_natureClasse='Competence'; 
 
  public function __construct($db)
  {
    parent::setRequete($this->_requete);
    parent::setNatureclasse($this->_natureClasse);
    parent::__construct($db);
  }

}

