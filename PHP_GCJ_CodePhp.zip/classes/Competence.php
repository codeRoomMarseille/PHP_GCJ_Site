<?php
class Competence
{
  
  private $_id, $_type, $_prestation ;
    
  public function __construct(array $donnees)
  {
    $this->hydrate($donnees);
  }
  
   
  public function hydrate(array $donnees)
  {
    foreach ($donnees as $key => $value)
    {
      $method = 'set'.ucfirst($key);
     if (method_exists($this, $method))
      {
        // echo '<p>'. $key . '-------' .$value.  '-------' .$method. '------- existe'.'</p>';
        $this->$method($value);
      }
    }
  }
  
   // GETTERS //
  
  public function getId()
  {
     return $this->_id;
  }


  public function getType()
  {
     return $this->_type;
  }

  public function getPrestation()
  {
     return $this->_prestation;
  }


  // SETTERS //
   
  public function setId($id)
  {
      $id = (int) $id;
      if ($id > 0){
          $this->_id=$id;
      }
  }



  public function setType($type)
  {
     if (is_string($type)){
          $this->_type=$type;
      }
  }



public function setPrestation($prestation)
{
    $prestation = (int) $prestation;
   if ($prestation > 0){
        $this->_prestation=$prestation;
    }
}




 
}