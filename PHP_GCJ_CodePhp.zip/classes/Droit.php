<?php
class Droit
{
  
  private $_id, $_niveau, $_nom ;
    
  public function __construct(array $donnees)
  {
    $this->hydrate($donnees);
  }
  
   
  public function hydrate(array $donnees)
  {
    foreach ($donnees as $key => $value)
    {
      $method = 'set'.ucfirst($key);
     if (method_exists($this, $method))
      {
        // echo '<p>'. $key . '-------' .$value.  '-------' .$method. '------- existe'.'</p>';
        $this->$method($value);
      }
    }
  }
  
   // GETTERS //
  
public function getId()
{
   return $this->_id;
}

public function getNom()
{
   return $this->_nom;
}


public function getNiveau()
{
   return $this->_niveau;
}




  // SETTERS //
   
  public function setId($id)
  {
      $id = (int) $id;
      if ($id > 0){
          $this->_id=$id;
      }
  }



  public function setNom($nom)
  {
     if (is_string($nom)){
      $this->_nom=$nom;
     }
  }


public function setNiveau($niveau)
{
   if (is_string($niveau)){
           $this->_niveau=$niveau;
    }
}



 
}