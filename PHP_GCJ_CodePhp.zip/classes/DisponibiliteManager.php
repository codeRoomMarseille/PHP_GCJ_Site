<?php
class DisponibiliteManager extends Manager
{
  public $_requete='SELECT disponibilite.Genre, disponibilite.Date, acteur.Login,acteur.EtatConnection, acteur.Nom, acteur.Prenom, acteur.Mail, acteur.Telephone, acteur.Adresse FROM disponibilite,acteur, salle where disponibilite.id_Acteur = acteur.id and disponibilite.id_Salle is null '; 
  public $_natureClasse='Disponibilite'; 
 
  public function __construct($db)
  {
    parent::setRequete($this->_requete);
    parent::setNatureclasse($this->_natureClasse);
    parent::__construct($db);
  }

}

