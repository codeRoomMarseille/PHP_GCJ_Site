	<!-- MENU DEBUT -->
	<div class="container-fluid">
		<!-- <div class="container"> -->
		 
		<div class="pos-f-t">
			
			<div class="collapse" id="navbarToggleExternalContent">
			 	<div class="bg-dark p-4">
				<p class="text-white">Vos menus sont liés à vos droits. Inscrivez vous ou identifiez vous pour accéder à nos prestations.</p>
				 <span class="text-muted"> Choisissez un menu </span> 

				<a href="/gcj" class="btn btn-warning" role="button">Début</a>

				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Consulter
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="/gcj/pages/Consulter/Prestations" niveau="100" >Prestations</a>
						<a class="dropdown-item" href="/gcj/pages/Consulter/Sessions" niveau="100" >Sessions</a>
					</div>
				</div>
				
				<div class="btn-group">
					<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Administrer
					</button>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="/gcj/pages/Administrer/Droits" niveau="400" >Droits</a>
						<a class="dropdown-item" href="/gcj/pages/Administrer/Salles" niveau="400" >Salles</a>
						<a class="dropdown-item" href="/gcj/pages/Administrer/Competences" niveau="400" >Compétences</a>
						<a class="dropdown-item" href="/gcj/pages/Administrer/Acteurs" niveau="400" >Acteurs</a>
						<a class="dropdown-item" href="/gcj/pages/Administrer/Attentes" niveau="400" >Attentes</a>
						<a class="dropdown-item" href="/gcj/pages/Administrer/Disponibilites" niveau="400" >Disponibilites</a>
					</div>
				</div>

			</div>

		</div>
			
			<nav class="navbar navbar-dark bg-dark">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
					<span class="small" > cliquez ici pour ouvrir ou fermer le menu </span>
				</button>
			</nav>

	</div>
	<!-- MENU FIN -->