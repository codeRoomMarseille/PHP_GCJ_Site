
	<div class="jumbotron text-center" style="margin-bottom:0">
  		<!-- <p>Guilde des codeurs juniors</p> -->
  		<a href="/gcj" ><span class="badge badge-pill badge-danger small" >Guilde des codeurs juniors</span></a>
  		<?php
			echo("Nous sommes le ".date("d-m-Y").'. Votre adresse IP est '.$_SERVER['REMOTE_ADDR']).'.';
		?>
	</div>

	<script src="/gcj/jQuery/jquery.min.js"></script>	
	<script src="/gcj/bootstrap/js/popper.min.js"></script>
	<script src="/gcj/bootstrap/js/bootstrap.min.js"></script>	
</body>
</html>