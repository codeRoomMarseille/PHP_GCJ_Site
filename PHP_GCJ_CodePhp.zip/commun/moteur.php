<?php 
	require_once($repertoireCommun.'start.php');
	require_once($repertoireCommun.'haut.php'); 
	require_once('./local.php'); 
	require_once($repertoireCommun.'bas.php'); 

?> 

