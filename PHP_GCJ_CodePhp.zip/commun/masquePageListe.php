<?php

$titreListe = $classe.'s';

$classe=$classe.'Manager';
$manager = new $classe($db);
$lignes = $manager->getAll();

if (empty($lignes))
{
  echo '<div class="alert alert-danger"> <strong> '.$messageAttention.' : </strong> '.$messageListeVide.' !</div>';
}
else
{

  ?>
  <div class="container-fluid">
    <h2><span class="badge badge-pill badge-success small" > <?php echo $titreListe ?></span> </h2>
    <p class="text-danger"> <?php echo $messageAlerteListe ?>  </p>
    <table class="table table-success table-hover">
      <thead>

          <?php
             echo '<tr>';
             foreach ($titres as $titre){
               echo '<th>' .$titre.'</td></th>';
             }
          ?>
        
      </thead>

      <tbody>
        <tr>

          <?php
            foreach ($lignes as $ligne){
              echo '<tr>';
              foreach ($titres as $titre){
                //echo($titre);
                $method = 'get'.ucfirst($titre);
                if (method_exists($ligne, $method)){
                 //echo($method);
                 echo '<td><small> ' .$ligne->$method().'</small></td>';
                }
              }
              echo '</tr>';
            }

          ?>

      </tr>
      </tbody>
    </table>
  </div>
<?php
  }
?>
