<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Guilde des codeurs juniors</title>
	<link rel="stylesheet" type="text/css" href="/gcj/bootstrap/css/bootstrap.min.css">
	<style>
	  .fakeimg {
	      height: 200px;
	      background: #aaa;
	  }
	</style>

</head>
<body>
	

	<?php require_once($_SERVER['DOCUMENT_ROOT'].'/gcj/commun/menuDynamique.php'); ?> 
 
	<div class="jumbotron text-center" style="margin-bottom:0">
		<h1><span class="badge badge-pill badge-success">Guilde des codeurs juniors</span></h1>
  		<p><span class="badge badge-success">Plus sérieux qu'il n'y parait !</span></p> 
	</div>

	 