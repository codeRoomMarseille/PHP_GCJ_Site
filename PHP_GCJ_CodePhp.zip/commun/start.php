<?php
// On enregistre notre autoload.

function chargerClasse($classname)
{
  require $_SERVER['DOCUMENT_ROOT'].'/gcj/classes/'.$classname.'.php';
}

spl_autoload_register('chargerClasse');

// on ouvre la bdd
$db = new PDO('mysql:host=localhost;dbname=gcj', 'root', '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING); // On émet une alerte à chaque fois qu'une requête a échoué.

?>