	<!-- MENU DEBUT -->
	<div class="container-fluid">
		<!-- <div class="container"> -->
		 
		<div class="pos-f-t">
			
			<div class="collapse" id="navbarToggleExternalContent">
			 	<div class="bg-dark p-4">
				<p class="text-white">Vos menus sont liés à vos droits. Inscrivez vous ou identifiez vous pour accéder à nos prestations.</p>
				 <!-- <span class="text-muted"> Choisissez un menu </span>  -->

				<ul><li><a href="/gcj" class="badge badge-pill badge-danger small" role="button">Première page</a></li></ul>

				
				<?php
					$depart = $_SERVER['DOCUMENT_ROOT']."\gcj\pages";
					$arbo = "/gcj/pages"
					?>

					<?php

					function list_dir($name,$arbo,$page) {
					  //echo('<br>'.'Fonction list_dir DEBUT ; '.$name.'<br>');
					  if ($dir = opendir($name)) {
					    while($file = readdir($dir)) {
					    
					      if( is_dir($name.'/'.$file) && !in_array($file, array(".","..","",'.','..',''))  && sizeof($file) != 0) {
					        echo('<ul>');
					        echo('<li ><a  href='.$arbo.'/'.$file.'  class="badge badge-pill badge-danger small" >'.$file.'</a></li>' );
					        list_dir($name.'/'.$file, $arbo.'/'.$file,$file);
					        echo('</ul>');
					      }
					    }
					    closedir($dir);
					  }
					}

					list_dir($depart,$arbo,"Pages");
				?>


			</div>

		</div>
			
			<nav class="navbar navbar-dark bg-dark">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
					<span class="badge badge-pill badge-danger small" > cliquez ici pour ouvrir ou fermer le menu </span>
				</button>
			</nav>

	</div>
	<!-- MENU FIN -->