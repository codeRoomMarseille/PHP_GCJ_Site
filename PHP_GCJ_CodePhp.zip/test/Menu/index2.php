<?php
$depart = "C:\wamp64\www\gcj\pages";
?>

<?php
function list_dir($name) {
  if ($dir = opendir($name)) {
    while($file = readdir($dir)) {
      if(is_dir($name.'/'.$file) && !in_array($file, array(".",".."))) {
?>
        <div class="btn-group">
        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <?php echo "$file";?>
        </button>
          <div class="dropdown-menu">
            <a  href="<?php echo "$name/$file" ?>" ><?php echo "$file" ?></a>
          </div>

 <?php

        list_dir($name.'/'.$file);
  ?> 
        </div>
        </div>
 <?php
     }
    }
    closedir($dir);
  }
}
list_dir($depart);
?>


