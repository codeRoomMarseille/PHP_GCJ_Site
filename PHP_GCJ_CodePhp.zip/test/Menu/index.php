<?php
$depart = "C:\wamp64\www\gcj\pages";
$arbo = "/gcj/pages"
?>

<?php

function list_dir($name,$arbo,$page) {
  //echo('<br>'.'Fonction list_dir DEBUT ; '.$name.'<br>');
  if ($dir = opendir($name)) {
    while($file = readdir($dir)) {
    
      if( is_dir($name.'/'.$file) && !in_array($file, array(".","..","",'.','..',''))  && sizeof($file) != 0) {
        echo('<ul>');
        echo("<li><a  href=".$arbo.'/'.$file." >".$file."</a></li>" );
        list_dir($name.'/'.$file, $arbo.'/'.$file,$file);
        echo('</ul>');
      }
    }
    closedir($dir);
  }
}

list_dir($depart,$arbo,"Pages");
?>


